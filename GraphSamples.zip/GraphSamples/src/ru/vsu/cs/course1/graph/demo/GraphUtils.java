package ru.vsu.cs.course1.graph.demo;

public class GraphUtils {
}
